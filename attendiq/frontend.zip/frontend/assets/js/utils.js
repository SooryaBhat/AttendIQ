// Shared JS helpers (placeholder)
